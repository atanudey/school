<?php
$name='Aegyptus';
$type='TTF';
$desc=array (
  'CapHeight' => 539,
  'XHeight' => 334,
  'FontBBox' => '[-110 -216 2541 788]',
  'Flags' => 4,
  'Ascent' => 784,
  'Descent' => -216,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 663,
);
$unitsPerEm=2048;
$up=-216;
$ut=10;
$strp=225;
$strs=50;
$ttffile='C:/wamp64/www/tst/lab/application/libraries/mpdf60/ttfonts/Aegyptus.otf';
$TTCfontID='0';
$originalsize=5841368;
$sip=false;
$smp=true;
$BMPselected=false;
$fontkey='aegyptus';
$panose=' c 3 5 7 1 2 1 7 7 7 7 7';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 784, -216, 0
// usWinAscent/usWinDescent = 784, -216
// hhea Ascent/Descent/LineGap = 784, -216, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'latn' => 'DFLT ',
);
$GSUBFeatures=array (
  'latn' => 
  array (
    'DFLT' => 
    array (
      'salt' => 
      array (
        0 => 0,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 5832584,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'latn' => 'DFLT ',
);
?>