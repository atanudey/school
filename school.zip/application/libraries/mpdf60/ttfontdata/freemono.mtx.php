<?php
$name='FreeMono';
$type='TTF';
$desc=array (
  'CapHeight' => 563,
  'XHeight' => 417,
  'FontBBox' => '[-793 -200 699 800]',
  'Flags' => 5,
  'Ascent' => 800,
  'Descent' => -200,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 600,
);
$unitsPerEm=1000;
$up=-125;
$ut=50;
$strp=258;
$strs=49;
$ttffile='C:/wamp64/www/tst/lab/application/libraries/mpdf60/ttfonts/FreeMono.ttf';
$TTCfontID='0';
$originalsize=584424;
$sip=false;
$smp=true;
$BMPselected=false;
$fontkey='freemono';
$panose=' 5 5 2 f 4 9 2 2 5 2 4 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, -200, 0
// usWinAscent/usWinDescent = 800, -200
// hhea Ascent/Descent/LineGap = 800, -200, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>