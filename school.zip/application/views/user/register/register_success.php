<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!--body panel starts -->
<div class="bodyPanel">
	<div class="loginPanelOuter">
		<h1>Thank you for registering with Educare!</h1>
		<div>
			<p>You have successfully register. Please check your email inbox to confirm your email address.</p>
		</div>
	</div><!-- .loginPanelOuter -->
</div>
<!--body panel ends--> 