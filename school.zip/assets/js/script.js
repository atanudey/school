$(function(){
	$('.navBar').click(function(){
		$('.dropDownMenu').stop().slideToggle(500);							
	})	   
});