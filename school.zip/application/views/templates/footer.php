<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!--footer starts -->
    <div class="footer">
    	<p>Copyright &copy; 2016 KRP Educare. All Rights Reserved. Powered By : <span><a href="#"><img src="<?= base_url('assets/images/footer-logo.png') ?>" /></a></span></p>
    </div>
    <!--footer ends -->
</body>
</html>