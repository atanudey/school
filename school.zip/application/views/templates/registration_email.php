Hi <?php $name ?>,

Thank you for registering with us. 

Thanks & Regards,
Educare