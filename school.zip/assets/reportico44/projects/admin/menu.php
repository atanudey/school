<?php
$menu_title = template_xlate(SW_PROJECT_TITLE);
$menu = array (
        array ( "language" => "en_gb", "report" => "", "title" => "BLANKLINE" ),
	array ( "language" => "en_gb", "report" => "createproject.xml", "title" => "Create A New Project" ),
	array ( "language" => "en_gb", "report" => "createtutorials.xml", "title" => "Configure Tutorials" ),
	);
?>
