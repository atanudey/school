<!--home bodyPanel starts-->
<div class="homeBodyPanel">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="optionBox">
                    <h2>User Registration</h2>
                    <div class="optionContent">
                        <img src="<?= base_url('/assets/images/option-pic-1.png') ?>" />
                        <h3>5 NEW EMAILS<span>Take Action</span></h3>
                    </div>
                    <p>educare.registration@krpsolutions.co.in has 5 New emails to take response.</p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="optionBox">
                    <h2>Enquery Emails</h2>
                    <div class="optionContent">
                        <img src="<?= base_url('/assets/images/option-pic-2.png') ?>" />
                        <h3>10 NEW EMAILS<span>Response</span></h3>
                    </div>
                    <p>info@krpsolutions.co.in has 10 New emails to response.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!--home bodyPanel ends-->