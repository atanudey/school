<?php
$locale_arr = array (
"language" => "French",
"template" => array (
        "T_en_gb" => "Anglais (UK)",
        "T_en_us" => "Anglais (US)",
        "T_fr_fr" => "Français",
        "T_es_es" => "Espagnol",
        "T_it_it" => "Italien",
        "T_ar_ar" => "Arabe",
        "T_zh_cn" => "Chinois (simplifié)",
),
);
?>
