<!--home bodyPanel starts-->
<div class="homeBodyPanel noBg">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <div class="leftContent">
                    <div class="leftContentInner">
                        <div class="mainHeading floatHolder">
                            <img src="<?= base_url('/assets/images/techno-logo.png') ?>" />
                            <div class="headingText">
                                <h1>Techno India</h1>
                                <p>Sector V Kolkata-700000<br />Tel - (033) 200-4567/1234</p>
                            </div>
                        </div>
                        <div class="mainContent">
                            <div class="mainContentInner">
                                <p>Donec eu libero sapien. Cras in euismod urna, eu sodales arcu. Quisque porttitor neque
                                    diam, vitae elementum turpis mollis in. Praesent vitae sem sollicitudin, volutpat
                                    turpis quis, facilisis neque. In vestibulum luctus condimentum. Nulla odio ex, posuere
                                    in magna eget, dapibus ornare nulla. Aliquam erat volutpat. In a ullamcorper lorem.
                                    Proin vitae feugiat massa. Praesent eu ipsum sit amet urna sagittis luctus in non
                                    sem. Phasellus tortor risus, pulvinar sed bibendum non, vehicula nec nunc. Nullam
                                    in elit metus. Fusce ut imperdiet nisi, eget aliquet ante. Phasellus dui nibh, egestas
                                    eu volutpat sit amet, efficitur vel risus. Etiam id sem est.</p>
                                <p>Praesent vitae sem sollicitudin, volutpat turpis quis, facilisis neque. In vestibulum
                                    luctus condimentum. Nulla odio ex, posuere in magna eget, dapibus ornare nulla. Aliquam
                                    erat volutpat. In a ullamcorper lorem. Proin vitae feugiat massa. Praesent eu ipsum
                                    sit amet urna sagittis luctus in non sem. Phasellus tortor risus, pulvinar sed bibendum.</p>
                                <p>Donec eu libero sapien. Cras in euismod urna, eu sodales arcu. Quisque porttitor neque
                                    diam, vitae elementum turpis mollis in. Praesent vitae sem sollicitudin, volutpat
                                    turpis quis, facilisis neque. In vestibulum luctus condimentum. Nulla odio ex, posuere
                                    in magna eget, dapibus ornare nulla. Aliquam erat volutpat. In a ullamcorper lorem.
                                    Proin vitae feugiat massa. Praesent eu ipsum sit amet urna sagittis luctus in non
                                    sem. Phasellus tortor risus, pulvinar sed bibendum non, vehicula nec nunc. Nullam
                                    in elit metus. Fusce ut imperdiet nisi, eget aliquet ante. Phasellus dui nibh, egestas
                                    eu volutpat sit amet, efficitur vel risus. Etiam id sem est.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="rightContentBlock">
                    <h3><span class="eventIcon"></span>Upcomming Events 2016</h3>
                    <div class="blockContentOuter eventContentPanelOuter">
                        <div class="blockContent eventContentPanel">
                            <div class="eventRow floatHolder">
                                <div class="dateBlock">
                                    <p>AUG <strong>15</strong> <span>Monday</span></p>
                                </div>
                                <div class="eventContent">
                                    <h4>Independence Day Celebration</h4>
                                    <p>Flag hostiong at 7.30 a.am National anthen song at 7.45 a.m Parred from 8 a.m to
                                        8.30 a.m. Breakfast from 8.30 a.m. All guardians are requested to attend the
                                        function.</p>
                                </div>
                            </div>
                            <div class="eventRow floatHolder">
                                <div class="dateBlock">
                                    <p>AUG <strong>15</strong> <span>Monday</span></p>
                                </div>
                                <div class="eventContent">
                                    <h4>Independence Day Celebration</h4>
                                    <p>Flag hostiong at 7.30 a.am National anthen song at 7.45 a.m Parred from 8 a.m to
                                        8.30 a.m. Breakfast from 8.30 a.m. All guardians are requested to attend the
                                        function.</p>
                                </div>
                            </div>
                            <div class="eventRow floatHolder">
                                <div class="dateBlock">
                                    <p>AUG <strong>15</strong> <span>Monday</span></p>
                                </div>
                                <div class="eventContent">
                                    <h4>Independence Day Celebration</h4>
                                    <p>Flag hostiong at 7.30 a.am National anthen song at 7.45 a.m Parred from 8 a.m to
                                        8.30 a.m. Breakfast from 8.30 a.m. All guardians are requested to attend the
                                        function.</p>
                                </div>
                            </div>
                            <div class="eventRow floatHolder">
                                <div class="dateBlock">
                                    <p>AUG <strong>15</strong> <span>Monday</span></p>
                                </div>
                                <div class="eventContent">
                                    <h4>Independence Day Celebration</h4>
                                    <p>Flag hostiong at 7.30 a.am National anthen song at 7.45 a.m Parred from 8 a.m to
                                        8.30 a.m. Breakfast from 8.30 a.m. All guardians are requested to attend the
                                        function.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="rightContentBlock noticeBoardPanel">
                    <h3><span class="noticeIcon"></span>Notice Board</h3>
                    <div class="blockContentOuter noticeContentPanelOuter">
                        <div class="blockContent noticeContentPanel">
                            <div class="noticeBoardRow">
                                <h4>Routine</h4>
                                <p>Class 9 routine for final examination for the year of 2015-2016.</p>
                                <h5><span><img src="<?= base_url('/assets/images/pdf-icon.png')?>" /></span>Click the icon to download the routine</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="mapArea">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d942538.6228720575!2d88.0923673!3d22.6615613!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1472929406217"
                        width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!--home bodyPanel ends-->